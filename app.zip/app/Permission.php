<?php

namespace App;

class Permission extends \Spatie\Permission\Models\Permission
{
}
