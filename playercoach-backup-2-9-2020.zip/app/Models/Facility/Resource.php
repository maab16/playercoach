<?php

namespace App\Models\Facility;

use Illuminate\Database\Eloquent\Model;

class Resource extends Model
{
    protected $cast = [
    	'business_hours' => 'array'
    ];

    protected $fillable = [
    	'booking_id',
    	'title',
    	'type',
    	'business_hours',
    ];
}
