<?php

return [

    'models' => [
    ],
    'middleware' => [
        \Codexshaper\Tenancy\Middleware\IdentifyHostname::class
    ],
    'website' => [
  
    ],
    'hostname' => [

        'system_hosts' => [
            'playercoach.com',
            'facility.playercoach.com'
        ],
        
    ],
    'db' => [

        'system_db' => env('TENANT_SYSTEM_DATABASE', 'playercoach'),

        'tenant_migrations_path' => database_path('migrations/tenant'),
    ],
];